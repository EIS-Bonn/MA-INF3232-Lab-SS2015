package com.example.eisuilogin;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.style.UnderlineSpan;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.FileOutputStream;
import com.example.eisuilogin.connection.*;

/**
 * This is the Log In View of the Green Energy Mobile Application.
 * In this View the user can either log in or sign up in order to 
 * user the application.
 *
 * @author Veronika Henk, Sarvenaz Golchin, Mahnaz Hajibaba
 * @version 1.0
 * @since 2014-05-30
 */
public class LoginActivity extends Activity {
	private EditText userlogin, passwordlogin;
	private TextView errormsg, label, questnew;
	private Button login, gosignup;

	/**
	  * Main method to build the View.
	  * TODO: details what is done exactly
	  *
	  * @param savedInstanceState saved state of the application
	  */
	//  TODO: Add check for internet access
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		/**
		 * Layout is set up
		 */
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login);
		
		login = (Button)findViewById(R.id.loginbutton);
		login.setText(getString(R.string.login));
		userlogin = (EditText)findViewById(R.id.username);
		passwordlogin = (EditText)findViewById(R.id.password);
		label = (TextView)findViewById(R.id.loginlabel);
		label.setText(getString(R.string.login));
		questnew = (TextView) findViewById(R.id.questnew);
		questnew.setText(getString(R.string.questnew));
		errormsg = (TextView) findViewById(R.id.errormsg);
		errormsg.setVisibility(View.INVISIBLE);
		login.setOnClickListener(new View.OnClickListener() {
            @Override
			public void onClick(View v) {
            	/**
            	 * Call the method to log in
            	 */
                login();
            }
        });
		
		gosignup = (Button) findViewById(R.id.gosignup);
		SpannableString linksignup = new SpannableString(getString(R.string.signup));
		linksignup.setSpan(new UnderlineSpan(), 0, linksignup.length(), 0);
		gosignup.setText(linksignup);
		
		gosignup.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				/**
				 * Forward to the Sign Up-View and finish this view so that it will not show up again.
				 */
				Intent gotologin = new Intent(LoginActivity.this, SignupActivity.class);
				gotologin.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
		        startActivity(gotologin);
		        finish();
				
			}
		});
	}

	/**
	 * Method to log in the user. 
	 * This method is called when the user presses the "Log In"-Button.
	 * 
	 * TODO: Write more details
	 */
	public void login(){
		/**
		 *  getting the username and password inserted by the user
		 */
		String username = userlogin.getText().toString();
		String password = passwordlogin.getText().toString();
		/**
		 *  the textview for error messages is set invisible as we do not have an error, yet
		 */
		errormsg.setVisibility(View.INVISIBLE);

		/**
		 *  checking if an username was inserted
		 */
		if(username.trim().equals("")) {
			/**
			 *  if username is empty an error message is displayed
			 */
			errormsg.setVisibility(View.VISIBLE);
			errormsg.setText("Please insert an username!");
		}
		else {
			/**
			 * an username was inserted, hence we try to log in the user by creating an instance of the Login-class.
			 * we use an Async-Task to execute the log in.
			 */
			Login login = new Login();
			login.execute(username, password);
			String result;
			try {
				/**
				 *  storing result (error-)code in the variable result
				 */
				result = login.get();
			} catch(Exception e) {
				/**
				 *  Log in was not successful: errorcode "-1" is stored in variable result
				 */
				result = "-1";
			}
			
			/**
			 *  checking if the log in was successful
			 */
			if(result.equals("0")) {
				/**
				 *  code "0" means that log in was successful
				 */
				try {
					/**
					 *  save username in a file on the device
					 */
					FileOutputStream fos = openFileOutput("username", Context.MODE_PRIVATE);
					fos.write(username.getBytes());
					fos.close();
					
					/**
					 *  save password in a file on the device
					 */
					FileOutputStream fos2 = openFileOutput("password", Context.MODE_PRIVATE);
					fos2.write(password.getBytes());
					fos2.close();
					
					/**
					 *  usage of Async-Task to receive latest score from database
					 */
					SyncScore sync = new SyncScore();
					sync.execute(username, password);
					/**
					 *  storing latest score in variable score
					 */
					String score = sync.get();
					/**
					 *  check if accessing score in database was successful
					 */
					if(!score.equals("-1")) {
						/**
						 *  accessing the score was successful:
						 *  score is written in a file on the device
						 */
						FileOutputStream fos3 = openFileOutput("score", Context.MODE_PRIVATE);
						fos3.write(score.getBytes());
						fos3.close();
					}
				} catch(Exception e) {
					/**
					 *  something went wrong
					 */
				}				
				
				/**
				 * If the log in was successful, we forward to MainActivity
				 */
				Intent gotomain = new Intent(LoginActivity.this, MainActivity.class);
		        startActivity(gotomain);
		        // this instance is finished
		        finish();
				
			}
			/**
			 * If the log in was not successful, a error message is displayed
			 */
			else {
				String errortext;
				/**
				 *  Converting the errorcodes in messages displayed to the user
				 */
				if(result.equals("1"))	errortext = "Connection could not be established!";
				else if(result.equals("2"))	errortext = "Username does not exist!";
				else if(result.equals("3"))	errortext = "The inserted password is not correct!";
				else	errortext = "An unexpected error occured!";
				
				// outputting the error messages
				errormsg.setVisibility(View.VISIBLE);
				errormsg.setText(errortext);
			}
		}
	}
}