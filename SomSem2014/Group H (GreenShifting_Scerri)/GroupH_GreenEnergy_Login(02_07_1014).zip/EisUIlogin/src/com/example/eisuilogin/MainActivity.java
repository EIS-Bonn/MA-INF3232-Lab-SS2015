// TODO: Include implementation style in documentation (usage of MVC pattern)

/**
 * This is the Main View of the Green Energy Mobile Application.
 * In this View the user data such as score and name, as well as 
 * the recommendation concerning energy consumption are displayed.
 *
 * @author Veronika Henk, Sarvenaz Golchin, Mahnaz Hajibaba
 * @version 1.0
 * @since 2014-05-30
 */
package com.example.eisuilogin;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.content.Context;
import android.content.Intent;
import java.io.*;

import com.example.eisuilogin.connection.*;


public class MainActivity extends Activity {
	private TextView scoreview, userview;
	private String score, username;
	
	/**
	  * Main method to build the View.
	  * TODO: Add more details
	  *
	  * @param savedInstanceState saved state of the application
	  */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		/*
		 * Layout is set up
		 */
		setContentView(R.layout.activity_main);
		scoreview = (TextView) findViewById(R.id.score);
		userview = (TextView) findViewById(R.id.usernameview);
        
        /*
    	 *  We test if the user is already logged in or not
    	 */
    	if(!isloggedin()) {
    		// If the user is not logged in, we forward to the Log In-View
    		Intent gotologin = new Intent(MainActivity.this, LoginActivity.class);
    		gotologin.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
    	       startActivity(gotologin);
    	       /*
    	        * This view is finished as it will be recreated when needed and 
    	        * we do not want more than one instance of this activity at a time.
    	        */
    	       finish();
    	}
    	else {
    		// If the user is already logged in, we display username and score
    		scoreview.setText(score);
    		userview.setText(username);
    	}
        
	}
	
	/**
	  * Method to log out the user.
	  * TODO: more details
	  *
	  * @param view associated view
	  */
	public void logout(View view){
		// Log In data is deleted from device, so that automatically log in of the user is prevented
		File dir = getFilesDir();
		new File(dir, "username").delete();
		new File(dir, "password").delete();
		new File(dir, "score").delete();
		
		// We forward to sing up view, as the main view is only visible to the user if he is logged in
		Intent gotologin = new Intent(MainActivity.this, LoginActivity.class);
		gotologin.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
        startActivity(gotologin);
        // We finish this instance of MainActivity
        finish();
	}
	
	/**
	 * Method to check is the user is already logged in.
	 * TODO: more details
	 * @return boolean value "true" or "false" revealing if the user is logged in
	 */
	private boolean isloggedin() {
		String password;
		try {
			/* 
			 * Try to read the files "username" and "password" on device
			 */
			FileInputStream fis = openFileInput("username");
			InputStreamReader in = new InputStreamReader(fis);
			BufferedReader br = new BufferedReader(in);
			// storing file content in variable username
			username = br.readLine();
			fis.close();
			
			FileInputStream fis2 = openFileInput("password");
			InputStreamReader in2 = new InputStreamReader(fis2);
			BufferedReader br2 = new BufferedReader(in2);
			// storing file content in variable password
			password = br2.readLine();
			fis2.close();
			
			/*
			 * Attempt to log in by creating an instance of the Login-class and executing the according Async-Task
			 */
			Login login = new Login();
			login.execute(username, password);
			String result;
			try {
				// storing result (error-)code in the variable result
				result = login.get();
				// checking if the log in was successful
				if(result.equals("0")) {
					// code "0" means that log in was successful
					try {
						// usage of Async-Task to receive latest score from database
						SyncScore sync = new SyncScore();
						sync.execute(username);
						// storing latest score in variable score
						score = sync.get();
						// check if accessing score in database was successful
						if(!score.equals("-1")) {
							/*
							 *  accessing the score was successful:
							 *  score is written in a file on the device
							 */
							FileOutputStream fos = openFileOutput("score", Context.MODE_PRIVATE);
							fos.write(score.getBytes());
							fos.close();
						}
					} catch(Exception e) { 
						// Something went wrong
					}
				}
			} catch(Exception e) {
				// Log in was not successful: errorcode "-1" is stored in variable result
				result = "-1"; 
			}
			
			/*
			 * Value of variable result is converted to a boolean value
			 */
			// log in was successful
			if(result.equals("0"))	return true;
			// log in was not successful
			else	return false;
		} catch(Exception e) {
			// if something else went wrong the user is not logged in
			return false;
		}
	}
	
}