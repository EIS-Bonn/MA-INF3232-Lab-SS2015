/**
 * This is the Log In View of the Green Energy Mobile Application.
 * In this View the user can either log in or sign up in order to 
 * user the application.
 *
 * @author Veronika Henk, Sarvenaz Golchin, Mahnaz Hajibaba
 * @version 1.0
 * @since 2014-05-30
 */
package com.example.eisuilogin;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.FileOutputStream;

import com.example.eisuilogin.connection.*;

public class SignupActivity extends Activity {
	private EditText usersignup, passwordsignup;
	private TextView errormsg, label, questnew;
	private Button signup, gotologin;

	/**
	  * Main method to build the View.	
	  * TODO: more details
	  *
	  * @param savedInstanceState saved state of the application
	  */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		/*
		 * Layout is set up
		 */
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login);
		signup = (Button)findViewById(R.id.loginbutton);
		signup.setText(getString(R.string.signup));
		signup.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				signup();
			}
		});
		usersignup = (EditText)findViewById(R.id.username);
		passwordsignup = (EditText)findViewById(R.id.password);
		label = (TextView) findViewById(R.id.loginlabel);
		label.setText(getString(R.string.signup));
		questnew = (TextView) findViewById(R.id.questnew);
		questnew.setVisibility(View.INVISIBLE);
		errormsg = (TextView) findViewById(R.id.errormsg);
		errormsg.setVisibility(View.INVISIBLE);
		gotologin = (Button) findViewById(R.id.gosignup);
		gotologin.setVisibility(View.INVISIBLE);
	}

	/**
	 * Method to sign up the user. 
	 * This method is called when the user presses the "Sign Up"-Button.
	 * TODO: more details
	 * 
	 * @param view associated view
	 */
	public void signup(){
		// getting the username and password inserted by the user
		String username = usersignup.getText().toString();
		String password = passwordsignup.getText().toString();
		// the textview for error messages is set invisible as we do not have an error, yet
		errormsg.setVisibility(View.INVISIBLE);
		
		// checking if an username was inserted
		if(username.trim().equals("")) {
			// if username is empty an error message is displayed
			errormsg.setVisibility(View.VISIBLE);
			errormsg.setText("Please insert an username!");
		}
		else if(password.trim().length() < 5) {
			// if password has less than 5 digits an error message is displayed
			errormsg.setVisibility(View.VISIBLE);
			errormsg.setText("Password must be at least 5 characters!");
		}
		else {
			/*
			 * we try to sign up the user by creating an instance of the Singup-class.
			 * we use an Async-Task to execute the sign up.
			 */
			Signup signup = new Signup();
			signup.execute(username, password);
			String result;
			try {
				// storing result (error-)code in the variable result
				result = signup.get();
			} catch(Exception e) {
				// Log in was not successful: errorcode "-1" is stored in variable result
				result = "-1";
			}
			
			// if signup was successful
			if(result.equals("0")) {
				// code "0" means that sign up was successful
				try {
					// save username in a file on the device
					FileOutputStream fos = openFileOutput("username", Context.MODE_PRIVATE);
					fos.write(username.getBytes());
					fos.close();
					
					// save password in a file on the device
					FileOutputStream fos2 = openFileOutput("password", Context.MODE_PRIVATE);
					fos2.write(password.getBytes());
					fos2.close();
					
					// score of this user is "0", as the account was just created
					String score = "0";
					// save score in file on device
					FileOutputStream fos3 = openFileOutput("score", Context.MODE_PRIVATE);
					fos3.write(score.getBytes());
					fos3.close();
				} catch(Exception e) {
					// something went wrong
				}	
				
				/*
				 * If the log in was successful, we forward to MainActivity
				 */
				Intent gotomain = new Intent(SignupActivity.this, MainActivity.class);
		        startActivity(gotomain);
		        // this instance is finished
		        finish();
			}
			
			/*
			* If the log in was not successful, a error message is displayed
			*/
			else {
				String errortext;
				// Converting the errorcodes in messages displayed to the user
				if(result.equals("1"))	errortext = "Connection could not be established!";
				else if(result.equals("2"))	errortext = "Username already exist!";
				else	errortext = "An unexpected error occured!";
				// outputting the error messages
				errormsg.setVisibility(View.VISIBLE);
				errormsg.setText(errortext);
			}
		}
	}
}