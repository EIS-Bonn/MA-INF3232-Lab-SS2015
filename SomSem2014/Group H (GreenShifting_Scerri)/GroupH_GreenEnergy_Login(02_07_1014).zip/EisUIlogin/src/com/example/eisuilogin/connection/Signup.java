/**
 * This is the Async-Task "Signup".
 * TODO: more details
 *
 * @author Veronika Henk, Sarvenaz Golchin, Mahnaz Hajibaba
 * @version 1.0
 * @since 2014-05-30
 */
package com.example.eisuilogin.connection;

import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

import android.os.AsyncTask;

public class Signup  extends AsyncTask<String,Void,String> {
	/*
	 * Server address: http://veronika-henk.de/greenenergy/signup.php
	 */

   String username, password;

   /**
	 * Method defines what needs to be done before the network connection is established.
	 * We do not have tasks (concerning) to be done beforehand.
	 */
   protected void onPreExecute(){ }
   
   /**
	 * Sending a request with sign up data to a web service in order to verify the data.
	 * TODO: more details
	 * 
	 * @param arg0[0] username which was inserted on the Login view
	 * @param arg0[1] password which was inserted on the Login view
	 * @return result of the network request: (error-)code
	 */
   @Override
   protected String doInBackground(String... arg0) {
	   try {
		   // accessing the data inserted by the user
		   username = (String)arg0[0];
           password = (String)arg0[1];
           
           // defining server address and parameters
           String link="http://veronika-henk.de/greenenergy/signup.php";
           String data  = URLEncoder.encode("username", "UTF-8")  + "=" + URLEncoder.encode(username, "UTF-8");
           data += "&" + URLEncoder.encode("password", "UTF-8")  + "=" + URLEncoder.encode(password, "UTF-8");
           URL url = new URL(link);
           
           // establishment of network connection and sending request
           URLConnection conn = url.openConnection(); 
           conn.setDoOutput(true); 
           OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream()); 
           wr.write( data ); 
           wr.flush(); 
           
           // using a buffered reader to access the result
           BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
           StringBuilder sb = new StringBuilder();
           String line = null;
           // read Server response
           while((line = reader.readLine()) != null) {
              sb.append(line);
              break;
           }
           // returning (error-)code
           return sb.toString();
	   }catch(Exception e){
		   // if an error occurred while establishing the connection the responding errorcode "1" is returned
		   return "1";
	   }
   }
   
   /**
	 * Method defines what needs to be done after the network connection is closed.
	 * We do not have tasks (concerning) to be done afterwards.
	 */
   @Override
   protected void onPostExecute(String result){ }
}
