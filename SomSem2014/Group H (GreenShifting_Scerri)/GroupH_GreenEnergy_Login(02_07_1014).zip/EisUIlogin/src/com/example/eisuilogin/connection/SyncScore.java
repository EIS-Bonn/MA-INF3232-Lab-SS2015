/**
 * This is the Async-Task "SyncScore".
 * It's purpose is to access the latest score which is stored on the server, 
 * so that it can replace score which is stored locally on a device.
 *
 * @author Veronika Henk, Sarvenaz Golchin, Mahnaz Hajibaba
 * @version 1.0
 * @since 2014-05-30
 */
package com.example.eisuilogin.connection;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

import android.os.AsyncTask;

public class SyncScore extends AsyncTask<String,Void,String> {
	/*
	 * Server address: http://veronika-henk.de/greenenergy/login.php
	 */
	String username, password;
	/**
	 * Method defines what needs to be done before the network connection is established.
	 * We do not have tasks (concerning) to be done beforehand.
	 */
	protected void onPreExecute(){ }
	
	/**
	 * Sending a request with a username to a web service in order to access the scores of this user.
	 * TODO: more details
	 * 
	 * @param arg0[0] username which was inserted on the Login view
	 * @return result of the network request: score
	 */
	@Override
	protected String doInBackground(String... arg0) {
		try {
			username = (String)arg0[0];
			
			// defining server address and parameters
	        String link="http://veronika-henk.de/greenenergy/getscore.php";
	        String data  = URLEncoder.encode("username", "UTF-8")  + "=" + URLEncoder.encode(username, "UTF-8");
	        URL url = new URL(link);
	        
	        // establishment of network connection and sending request
	        URLConnection conn = url.openConnection(); 
	        conn.setDoOutput(true); 
	        OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream()); 
	        wr.write( data ); 
	        wr.flush(); 
	        
	        // using a buffered reader to access the result 
	        BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
	        StringBuilder sb = new StringBuilder();
	        String line = null;
	        // read Server response
	        while((line = reader.readLine()) != null) {
	           sb.append(line);
	           break;
	        }
	        // returning score
	        return sb.toString();
		}catch(Exception e){
			// if an error occurred while establishing the connection "-1" is returned
			return "-1";
		}
	}

	/**
	 * Method defines what needs to be done after the network connection is closed.
	 * We do not have tasks (concerning) to be done afterwards.
	 */
   @Override
   protected void onPostExecute(String result){ }
}

