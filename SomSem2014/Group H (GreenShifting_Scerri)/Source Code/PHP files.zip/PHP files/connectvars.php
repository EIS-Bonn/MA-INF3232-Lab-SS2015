<?php
  // Define database connection constants
  define('DB_HOST', '<insert_host_here>');
  define('DB_USER', '<insert_db_username_here>');
  define('DB_PASSWORD', '<insert_db_password_here>');
  define('DB_NAME', '<insert_name_of_database_here>');
?>
