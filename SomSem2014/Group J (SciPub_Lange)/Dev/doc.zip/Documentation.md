* [Tutorial](#tutorial)
    * [How to annotate table?](#how-to-annotate-table)
    * [How to add annotations?](#how-to-add-annotations)
    * [How to fetch existing annotations?](#how-to-fetch-existing-annotations)
    * [Find similar publications](#find-similar-publications)
    * [In case of issues](#in-case-of-issues)
* [Installation Guide](#installation-guide)
* [Changelog](#changelog)

## Tutorial
Please follow the [installation guide](#installation-guide) in order to get started. Then open a PDF file from the "Open File" on the toolbar of the tool.

Now you can start annotating...
###How to annotate table?
Select a table text information from the PDF. Then try to select the whole table or at least first three (3) rows. Then press "Annotate table" button. If the table was partially selected then system will ask a option to select the whole table automatically. Once the selection is done the parse information from the PDF document will show in the output window. If the selection is satisfactory then press the "Confirm annotation" button. And then it will successfully upload the table information as a datacube vocabulary.


![add](https://cloud.githubusercontent.com/assets/7385322/4346514/2d99d30e-4103-11e4-92e9-4db48f747ebb.gif)

###How to add annotations?
Select text in the PDF file, it will appear in the "Subject" field. 

Fill in the "Property" and "Object" fields. Properties denote the connection type between the selected text and its subject, eg "is about", "related to" etc. Objects are classifications of the selected text in relation to its properties, eg "computer science", "company" etc. You can type your own values or use existing ones in the database. It is best to reuse existing values if they suit the purpose - this gets better results with the similar publications functionality. NB! Since you are running on a local copy of your database you need to add some annotations first for the suggestions to become available. When all three fields are filled, click on "Add annotation" button. The triples get now uploaded to the database.

![add](https://cloud.githubusercontent.com/assets/5968369/2618934/35e4d28a-bc28-11e3-999d-4424d2dfafa3.gif)

###How to fetch existing annotations?
You can fetch existing annotations for the open file by pressing on the "Fetch annotations" button. This fetches all existing annotations for the given file added by you or anyone else and displays them as highlights in the PDF file.

![fetch](https://cloud.githubusercontent.com/assets/5968369/2618930/2ca19532-bc28-11e3-9ae8-0a7ee14560f3.gif)

###Find similar publications
The current functionality of this is still in early stages. Pressing "Find Similar" button returns results if there exist annotations for other files in the database that are associated to matching objects in the open file. To check which objects there are for the current file, press the "Fetch annotations" link and see the values in the last column. Returned results are ordered in descending order of importance. That means that files with a higher count of matching objects are displayed at the top of the list.

![similar](https://cloud.githubusercontent.com/assets/5968369/2618920/22ebd35e-bc28-11e3-86e4-1f07e281fea2.gif)

###In case of issues
This is an early prototype and you might still run into issues. We ask you to please register them as [new issues](https://github.com/saifulnipo/eis-semantic-annotation/issues) so they can get solved. Include a detailed description of the behaviour and if possible add the logs from the console window (F12).

## Installation Guide
[Download the tool](https://github.com/saifulnipo/eis-semantic-annotation/releases) to your local machine. Continue with the installation of the database...

**Windows**

1. Install [Openlink Virtuoso](http://www.openlinksw.com/dataspace/doc/dav/wiki/Main/VOSDownload) database.
2. Follow the [basic installation](http://www.openlinksw.com/dataspace/doc/dav/wiki/Main/VOSUsageWindows#Basic Installation) guide of Virtuoso.
3. Set the PATH [system environment variable](http://www.openlinksw.com/dataspace/doc/dav/wiki/Main/VOSUsageWindows#Prerequisites) on your system.
4. Create a [Virtuoso Windows Service](http://www.openlinksw.com/dataspace/doc/dav/wiki/Main/VOSUsageWindows#Optional -- Create and Manage Virtuoso Windows Services).
5. Open [http://localhost:8890/conductor](http://localhost:8890/conductor) administration tool in your browser. login/psswd: dba/dba
6. Add write access from the administration tool for the SPARQL editor when you are logged in: System Admin > User Accounts > SPARQL edit > add role: SPARQL_UPDATE. This allows the Annotation tool to insert data to the database.
7. Add your account (with what you log in: eg "dba") to the role : SPARQL_UPDATE under the tab "roles" in the administration tool.
8. Go to [http://localhost:8890/sparql](http://localhost:8890/sparql) > GRANT EXECUTE ON DB.DBA.L_O_LOOK TO "SPARQL" > press "Run Query" button. This step is necessary to avoid the error "No permission to execute dpipe DB.DBA.L_O_LOOK" ([bug](https://www.mail-archive.com/virtuoso-users@lists.sourceforge.net/msg06123.html) for WIN edition)

**Linux (ubuntu)**

The following incomplete guide, for ubunty [Ubuntu installation](http://virtuoso.openlinksw.com/dataspace/doc/dav/wiki/Main/VOSUbuntuNotes).
Following is some of the important note about installation 

_Open the terminal and follow the next steps_

1. Be sure to update the index of available packages:
 * `sudo apt-get update`
2. To install the basic version 
 * `sudo apt-get install  virtuoso-opensource`
3. when the password window is pop up please provide the password for both `dba` and `dav` then confirm password to continue the installation. (common password normally used as  `dba`)
4. After finishing the installation the the virtuoso server is automatically running. The admin console is  is available [admin conductor](http://localhost:8890/conductor).
5. Continue by opening [http://localhost:8890/conductor](http://localhost:8890/conductor) and following steps 5, 6 and 7 of the previous (windows installation) instructions given above.

**Mac** 

Following is the complete installation for mac. [Macbook installation](https://code.google.com/p/junsbriefcase/wiki/NotesAboutVirtuoso)

Bellow is some of main points, how to install virtuoso step by step.

1. Make a directory any where in our local machine.
2. Open terminal and go to that directory and star executing the following command one by one. The whole process will take a while, so get back and relax :-)
 * `git clone https://github.com/openlink/virtuoso-opensource.git`
 * `cd virtuoso-opensource`
 * `brew install libtool`
 * `brew install gawk`
 * `./autogen.sh`
 * `export CFLAGS="-O -m64 -mmacosx-version-min=10.8"`
 * `./configure`
 * `make`
 * `make install`
 * `echo "PATH=/usr/local/virtuoso-opensource/bin:$PATH #Add Virtuoso" >> ~/.bash_profile`
3. Once done with all the steps then need to start he server. Go to the following directory 
 * `cd /usr/local/virtuoso-opensource/var/lib/virtuoso/db`
 *  Start  the server by running the command: `sudo virtuoso-t -f`
4. In-order to stop the server one need to login the sparql command line 
 * `isql 1111 dba dba` and then type `shutdown();`

### **Default step for all operating system**

After successfully install the Virtuoso, we need to enabling [Cross-Origin Resource Sharing (CORS)](http://virtuoso.openlinksw.com/dataspace/doc/dav/wiki/Main/VirtTipsAndTricksCORsEnableSPARQLURLs) for Virtuoso SPARQL Endpoint, to POST communicate via ajax request.

###Still having problems?
**Windows**

Try to isolate the problem:
* Open your SPARQL editor: [http://localhost:8890/sparql](http://localhost:8890/sparql). Does it open up?
    * If the link does not open then it might be because your Windows Service is down. Start it manually: go to Start > "Services" > look for "Openlink Virtuoso Server [instance name]". If the service is not in "Started" status, then right-click start. if the service starts and then immediately stops (with an error message), then delete %VIRTUOSO_HOME%\database\virtuoso.lck file and create a new windows service instance as per installation instructions. It should now start successfully.
    * If the link opens without problems, run the default query. Does it return results?
* If the above point seemed fine then there might be an issue in the communication between the tool and the SPARQL editor. You might need to check some variables in the Annotation tool.
    * Make sure SERVER_ADDRESS variable in sparql.js is set to your local SPARQL query editor address, the default should be [http://localhost:8890/sparql](http://localhost:8890/sparql). If needed you can change the default graph name "scientificAnnotation" in scientificAnnotation.js.
* To check if you managed to successfully load any information into the database, you can run the following query in SPARQL editor [http://localhost:8890/sparql](http://localhost:8890/sparql): SELECT * FROM <scientificAnnotation> WHERE { ?s ?p ?o }

## Changelog
[v1.0](https://github.com/saifulnipo/eis-semantic-annotation/releases/tag/v1.0) - 07.2014, current milestone