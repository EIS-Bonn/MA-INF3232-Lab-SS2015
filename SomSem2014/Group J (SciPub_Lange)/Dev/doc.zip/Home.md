### Semantic Table Annotation Tool for EIS related PDF documents 
This is a tool to annotate tabular data in a EIS related PDF document.  
This project is a idea of how semantic table annotation of PDF files could work via crowd sourcing effort. This tool primary focus on tabular annotation using **datacube** vocabulary.

![highlights](https://cloud.githubusercontent.com/assets/7385322/4346514/2d99d30e-4103-11e4-92e9-4db48f747ebb.gif)

* [Documentation](https://github.com/saifulnipo/eis-semantic-annotation/wiki/Documentation)
* [System Architecture](https://github.com/saifulnipo/eis-semantic-annotation/wiki/System-Architecture-Diagram)
* [Libraries used](https://github.com/saifulnipo/eis-semantic-annotation/wiki/Libraries-Used)

**Demo videos:**

|Simple Table annotation|How annotations work|How similar papers work|
|---------|---------|---------|
|[![Demo of the tool](http://img.youtube.com/vi/i4oXo01cpVY/1.jpg)](https://www.youtube.com/watch?v=i4oXo01cpVY)|[![Demo of the tool](http://img.youtube.com/vi/TzkwgSuAEGc/1.jpg)](http://www.youtube.com/watch?v=TzkwgSuAEGc)|[![Demo of the tool](http://img.youtube.com/vi/dOdSOHXSjT8/1.jpg)](http://www.youtube.com/watch?v=dOdSOHXSjT8)|