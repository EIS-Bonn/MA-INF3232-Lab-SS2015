The following libraries were used in the implementation organised by milestones.
* [Rangy API](#rangy-api)
* [Typeahead](#typeahead)
* [PDF.js](#pdfjs)
* [Bootstrap](#bootstrap)
* [JQuery](#jquery)

## Rangy API
A cross-browser JavaScript range, selection and highlighting library that the project uses for the following tasks:
* highlighting annotations
* text fragment identification

![highlight](https://cloud.githubusercontent.com/assets/5968369/2595346/b023ee18-ba99-11e3-92a5-f726ec26a80f.png) 

**[v1.0](https://github.com/saifulnipo/eis-semantic-annotation/releases/tag/v1.0)**<br/>
Version: [1.3alpha.804](https://code.google.com/p/rangy/downloads/detail?name=rangy-1.3alpha.804.zip) <br/>
Project path: `/libs`

| Module | Description |
|--------|--------|
|rangy-core.js | The following modules are dependent on this.|
| [rangy-serializer.js](https://code.google.com/p/rangy/wiki/SerializerModule) | Serializes and deserializes text fragment ranges and selections. Serialised formats of text selections can then be uploaded to a triple store and retrieved for later display. |
| [rangy-cssclassapplier.js](https://code.google.com/p/rangy/wiki/CSSClassApplierModule) | This module adds and removes CSS classes on all text nodes within a Range or Selection. The project uses this for applying CSS span classes to annotations for highlighting purposes. |

## Typeahead
Library for implementing autocomplete search functionality. The project uses this for offering auto-complete suggestions for properties and objects in the UI.

![typeahead](https://cloud.githubusercontent.com/assets/5968369/2596419/138ecc0e-baa7-11e3-9feb-9fef0a04f18b.png)

**[v1.0](https://github.com/saifulnipo/eis-semantic-annotation/releases/tag/v1.0)**<br/>
Version: [0.9.3](https://github.com/twitter/typeahead.js/blob/master/CHANGELOG.md#093-june-24-2013) <br/>
Project path: `/libs`

## PDF.js
Javascript platform for parsing and rendering PDFs. Viewer Example is used as a base for the project. The project uses this for PDF file rendering in the browser.

![pdf.js](https://cloud.githubusercontent.com/assets/5968369/2596739/dc4c28a0-baaa-11e3-8818-59dac22affd2.png)

**[v1.0](https://github.com/saifulnipo/eis-semantic-annotation/releases/tag/v1.0)**<br/>
Version: [unknown?](http://mozilla.github.io/pdf.js/) <br/>
Project path: `/libs`

## Bootstrap
Powerful framework for intuitive UI development. The project uses them for buttons, input fields etc UI components. Requires [JQuery](#jquery).

![bootstrap](https://cloud.githubusercontent.com/assets/5968369/2597056/b0db41a2-baae-11e3-8602-9b9d8ed2ec60.png)

**[v1.0](https://github.com/saifulnipo/eis-semantic-annotation/releases/tag/v1.0)**<br/>
Version: [3.0.0](http://getbootstrap.com/) <br/>
Project path: `/libs`

## JQuery
DOM manipulation, event handling and ajax javascript library. Required by [bootstrap](#bootstrap). The project uses this mostly for requesting triples via ajax and for its other convenience methods.

**[v1.0](https://github.com/saifulnipo/eis-semantic-annotation/releases/tag/v1.0)**<br/>
Version: [2.0.3](http://jquery.com/) <br/>
Project path: `/libs`