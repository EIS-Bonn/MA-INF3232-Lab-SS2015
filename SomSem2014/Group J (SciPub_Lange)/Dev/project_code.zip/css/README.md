## This folder contain project style sheet
- bootstrap
- highlight
- pdf viewer
- application main window style sheet