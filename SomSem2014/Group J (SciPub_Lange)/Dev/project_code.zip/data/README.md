## This folder contain sparql data structure related files
- table data cube structure