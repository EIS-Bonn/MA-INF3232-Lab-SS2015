## This folder contain External library
- JPEG specificatio
- webL10n is a client-side, cross-browser i18n/l10n library (internationalization / localization)