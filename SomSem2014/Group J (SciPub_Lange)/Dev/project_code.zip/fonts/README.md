## This folder contain fonts
- This fonts is used during the application UI rendering, via css
