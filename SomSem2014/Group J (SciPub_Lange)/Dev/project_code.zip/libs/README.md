### Project Core Library

This directory contain all the external library

- [PDF.js](http://mozilla.github.io/pdf.js/) - Viewer Example is used as a base for the project
- [Twitter bootstrap](http://getbootstrap.com/) - used for UI
- [jQuery](http://jquery.com/) - used for DOM manipulations, required by Twitter bootstrap
- [Typeahead.js](https://github.com/twitter/typeahead.js) - used for autosuggestion in input boxes
- [Ranjy](https://code.google.com/p/rangy/) - A cross-browser JavaScript range and selection library.
