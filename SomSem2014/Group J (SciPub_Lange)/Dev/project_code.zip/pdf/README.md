### Sample PDF file to for testing purpose

This directory contain input pdf files for project testing purpose.
