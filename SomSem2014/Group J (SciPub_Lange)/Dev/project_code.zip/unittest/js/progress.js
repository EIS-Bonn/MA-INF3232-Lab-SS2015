var progress = {

    progressbar: function() {
        return true;
    },

    hideProgressBar: function(){
        return true;
    }

};

