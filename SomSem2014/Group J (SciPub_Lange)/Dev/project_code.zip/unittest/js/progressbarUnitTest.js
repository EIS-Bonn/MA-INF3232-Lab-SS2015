var progressbarUnitTest = {

    ShowProgressbarUnitTest: function() {
        return  (progressbar.showProgressBar("") == $('.progress-bar').html());
    }
};


  
