/**
 * This file contain the unit test of libs/sparqlResponseParser.js file
 *
 * @authors : A Q M Saiful Islam
 *
 */
/*global QUnit:false, sparql :false */

var sparqlResponseParserUnitTest = {

    testIsParsePropertySuccess : function() {
        return true;
    }

};